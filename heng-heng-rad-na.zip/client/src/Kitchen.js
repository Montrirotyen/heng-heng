
import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import './App.css';

const socket = io('http://localhost:5000');

function Kitchen() {
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [language] = useState('th'); // 'th', 'en', 'cn' (fixed to Thai for kitchen)
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState([]);
  const audioRef = useRef(null);

  useEffect(() => {
    fetch('http://localhost:5000/api/orders')
      .then(res => res.json())
      .then(data => setOrders(data));
    fetch('http://localhost:5000/api/menu')
      .then(res => res.json())
      .then(data => setMenuItems(data));

    // เตรียม audio
    if (!audioRef.current) {
      audioRef.current = new window.Audio('/notification.mp3');
    }

    socket.on('new_order', (newOrder) => {
      setOrders(prev => [newOrder, ...prev]);
      // เล่นเสียงแจ้งเตือน
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        const playPromise = audioRef.current.play();
        if (playPromise && typeof playPromise.then === 'function') {
          playPromise.catch(() => {}); // ignore error if user hasn't interacted
        }
      }
    });
    socket.on('order_updated', (updatedOrder) => {
      setOrders(prev => prev.map(order => order.id === updatedOrder.id ? updatedOrder : order));
    });
    socket.on('table_cleared', (data) => {
      setOrders(prev => prev.filter(order => order.tableNumber !== data.tableNumber));
    });
    return () => {
      socket.off('new_order');
      socket.off('order_updated');
      socket.off('table_cleared');
    };
  }, []);

  // ฟังก์ชันดึงประวัติย้อนหลังจาก backend
  const fetchHistory = () => {
    fetch('http://localhost:5000/api/order-history')
      .then(res => res.json())
      .then(data => {
        setHistory(data);
        setShowHistory(true);
      });
  };

  const getMenuName = (item) => {
    if (language === 'en' && item.name_en) return item.name_en;
    if (language === 'cn' && item.name_cn) return item.name_cn;
    return item.name;
  };

  const handleStatusChange = (order, nextStatus) => {
    fetch(`http://localhost:5000/api/orders/${order.id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus })
    });
  };

  const statusFlow = ['ใหม่', 'กำลังทำ', 'เสิร์ฟแล้ว', 'เสร็จสิ้น'];

  // ฟังก์ชันคำนวณราคาต่อชิ้น (รวม option)
  const getItemTotalPrice = (item) => {
    let extra = 0;
    if (item.options?.ขนาด === 'พิเศษ') extra += 10;
    if (item.options?.เพิ่มเติม && Array.isArray(item.options.เพิ่มเติม)) {
      if (item.options.เพิ่มเติม.includes('ห่อไข่')) extra += 10;
      if (item.options.เพิ่มเติม.includes('ไข่ดาว')) extra += 10;
      if (item.options.เพิ่มเติม.includes('ไข่เจียว')) extra += 10;
    }
    return (item.price + extra) * item.quantity;
  };

  // ฟังก์ชันคำนวณยอดรวมของออเดอร์ (ใช้ getItemTotalPrice)
  const getOrderTotal = (order) => order.items.reduce((sum, item) => sum + getItemTotalPrice(item), 0);

  return (
    <div className="container kitchen-container">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 10, position:'relative', zIndex:2}}>
        <h1 className="text-center" style={{margin:0, zIndex:1}}>หน้าครัว</h1>
        <button onClick={fetchHistory} style={{background:'#2196F3', color:'#fff', border:'none', borderRadius:5, padding:'8px 18px', fontWeight:600, fontSize:16, cursor:'pointer', zIndex:3, position:'relative'}}>ดูประวัติย้อนหลัง</button>
      </div>
      {!showHistory ? (
        <>
        <h2>ออเดอร์ปัจจุบัน</h2>
        <div className="order-list">
          {orders.length === 0 ? (
            <div className="no-orders">ยังไม่มีออเดอร์</div>
          ) : (
            orders.map(order => (
              <div key={order.id} className="order-card">
                <div className="order-header">
                  <h3>#{order.id} โต๊ะ {order.tableNumber}</h3>
                  <span className={`status-badge status-${order.status}`}>{order.status}</span>
                </div>
                <ul className="item-list">
                  {order.items.map((item, idx) => (
                    <li key={idx}>
                      {getMenuName(item)}
                      {item.options?.เส้น ? ` (เส้น: ${item.options.เส้น})` : ''}
                      {item.options?.ขนาด ? ` (ขนาด: ${item.options.ขนาด}${item.options.ขนาด === 'พิเศษ' ? '+10' : ''})` : ''}
                      {item.options?.เพิ่มเติม && item.options.เพิ่มเติม.length > 0 ? ` (เพิ่มเติม: ${item.options.เพิ่มเติม.join(', ')}${item.options.เพิ่มเติม.includes('ห่อไข่') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่ดาว') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่เจียว') ? '+10' : ''})` : ''}
                      {' '}x {item.quantity}
                    </li>
                  ))}
                </ul>
                <div className="order-footer">
                  <b>รวม {getOrderTotal(order)} บาท</b>
                  <div style={{marginTop:10}}>
                    {order.status !== 'เสร็จสิ้น' && (
                      <button className={`confirm-button${order.status === 'เสิร์ฟแล้ว' ? ' complete-button' : ''}`}
                        onClick={() => handleStatusChange(order, statusFlow[statusFlow.indexOf(order.status)+1])}
                        disabled={statusFlow.indexOf(order.status) === statusFlow.length-1}
                      >
                        {order.status === 'ใหม่' && 'เริ่มทำอาหาร'}
                        {order.status === 'กำลังทำ' && 'เสิร์ฟแล้ว'}
                        {order.status === 'เสิร์ฟแล้ว' && 'เสร็จสิ้น'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        </>
      ) : (
        <>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 10}}>
          <h2 style={{margin:0}}>ประวัติย้อนหลัง</h2>
          <button onClick={() => {
            setShowHistory(false);
            // รีเฟรชออเดอร์ปัจจุบันใหม่เมื่อปิดประวัติ
            fetch('http://localhost:5000/api/orders')
              .then(res => res.json())
              .then(data => setOrders(data));
          }} style={{background:'#aaa', color:'#fff', border:'none', borderRadius:5, padding:'6px 16px', fontWeight:600}}>กลับ</button>
        </div>
        <div className="order-list">
          {history.length === 0 ? (
            <div className="no-orders">ยังไม่มีประวัติ</div>
          ) : (
            history.map(order => {
              // แปลงวันที่/เวลา
              let dateStr = '';
              if (order.createdAt) {
                const d = new Date(order.createdAt);
                const pad = n => n.toString().padStart(2, '0');
                dateStr = `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
              }
              return (
              <div key={order.id} className="order-card">
                <div className="order-header">
                  <h3>#{order.id} โต๊ะ {order.tableNumber}</h3>
                  <span className={`status-badge status-${order.status}`}>{order.status}</span>
                </div>
                <div style={{fontSize:'1rem', color:'#888', marginBottom:6}}>
                  {dateStr && <>สั่งเมื่อ: {dateStr}</>}
                </div>
                <ul className="item-list">
                  {order.items.map((item, idx) => (
                    <li key={idx}>
                      {getMenuName(item)}
                      {item.options?.เส้น ? ` (เส้น: ${item.options.เส้น})` : ''}
                      {item.options?.ขนาด ? ` (ขนาด: ${item.options.ขนาด}${item.options.ขนาด === 'พิเศษ' ? '+10' : ''})` : ''}
                      {item.options?.เพิ่มเติม && item.options.เพิ่มเติม.length > 0 ? ` (เพิ่มเติม: ${item.options.เพิ่มเติม.join(', ')}${item.options.เพิ่มเติม.includes('ห่อไข่') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่ดาว') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่เจียว') ? '+10' : ''})` : ''}
                      {' '}x {item.quantity}
                    </li>
                  ))}
                </ul>
                <div className="order-footer">
                  <b>รวม {getOrderTotal(order)} บาท</b>
                </div>
              </div>
            )})
          )}
        </div>
        </>
      )}
    </div>
  );
}

export default Kitchen;
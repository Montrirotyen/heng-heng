
import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import io from 'socket.io-client';
import './App.css';

const socket = io('http://localhost:5000');

function Customer() {
  const [menuItems, setMenuItems] = useState([]);
  const [language, setLanguage] = useState('th'); // 'th', 'en', 'cn'
  const [selectedItems, setSelectedItems] = useState([]);
  const [tableNumber, setTableNumber] = useState(null);
  const [tableOrders, setTableOrders] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);
  const [options, setOptions] = useState({
    เส้น: null,
    ขนาด: null,
    เพิ่มเติม: []
  });
  const [isOrdering, setIsOrdering] = useState(false); // ป้องกันกดเบิ้ล

  const location = useLocation();
  const hasFetchedMenuItems = useRef(false);

  const fetchTableData = (table) => {
    if (!hasFetchedMenuItems.current) {
        fetch('http://localhost:5000/api/menu')
            .then(res => res.json())
            .then(data => {
                setMenuItems(data);
                hasFetchedMenuItems.current = true;
            });
    }

    if (table) {
        fetch(`http://localhost:5000/api/orders/table/${table}`)
            .then(res => res.json())
            .then(data => setTableOrders(data));
    }
  };

  // ฟังก์ชันสำหรับเพิ่มเครื่องดื่มลงตะกร้า (หรือเมนูที่ไม่ต้องเลือก option)
  const handleAddItem = (item) => {
    const newItem = { ...item, quantity: 1, options: item.options || {} };
    const existingItemIndex = selectedItems.findIndex(
      i => i.id === newItem.id && JSON.stringify(i.options) === JSON.stringify(newItem.options)
    );
    if (existingItemIndex > -1) {
      const updatedItems = [...selectedItems];
      updatedItems[existingItemIndex].quantity += 1;
      setSelectedItems(updatedItems);
    } else {
      setSelectedItems(prevItems => [...prevItems, newItem]);
    }
  };

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const table = searchParams.get('table');
    setTableNumber(table);
    fetchTableData(table);

    socket.on('new_order', (newOrder) => {
        if (newOrder.tableNumber === table) {
            setTableOrders(prevOrders => [newOrder, ...prevOrders]);
        }
    });

    socket.on('order_updated', (updatedOrder) => {
        if (updatedOrder.tableNumber === table) {
            setTableOrders(prevOrders => prevOrders.map(order =>
                order.id === updatedOrder.id ? updatedOrder : order
            ));
        }
    });

    socket.on('table_cleared', (data) => {
        if (data.tableNumber === table) {
            console.log(`Table ${table} was cleared. Resetting view.`);
            setTableOrders([]);
            setSelectedItems([]);
        }
    });

    return () => {
        socket.off('new_order');
        socket.off('order_updated');
        socket.off('table_cleared');
    };
  }, [location.search]);

  // Handle opening modal for selecting options
  const handleOpenModal = (menuItem) => {
    setCurrentItem(menuItem);
    setOptions({
        เส้น: menuItem.options?.เส้น ? menuItem.options.เส้น[0] : null,
        ขนาด: menuItem.options?.ขนาด ? menuItem.options.ขนาด[0] : null,
        เพิ่มเติม: []
    });
    setShowModal(true);
  };
  
  // Handle adding item to cart from modal
  const handleAddItemFromModal = () => {
      const newItem = { ...currentItem, 
          quantity: 1, 
          options: { ...options }
      };
      
      const existingItemIndex = selectedItems.findIndex(item => 
          item.id === newItem.id && JSON.stringify(item.options) === JSON.stringify(newItem.options)
      );

      if (existingItemIndex > -1) {
          const updatedItems = [...selectedItems];
          updatedItems[existingItemIndex].quantity += 1;
          setSelectedItems(updatedItems);
      } else {
          setSelectedItems(prevItems => [...prevItems, newItem]);
      }
      
      setShowModal(false);
  };
  
  const handleCloseModal = () => {
      setShowModal(false);
  };

  const handlePlus = (index) => {
    setSelectedItems(prevItems => 
      prevItems.map((item, i) => 
        i === index ? { ...item, quantity: item.quantity + 1 } : item
      )
    );
  };

  const handleMinus = (index) => {
    setSelectedItems(prevItems => {
        const updatedItems = prevItems.map((item, i) => 
            i === index ? { ...item, quantity: item.quantity - 1 } : item
        ).filter(item => item.quantity > 0);
        return updatedItems;
    });
  };

  const handleOrderSubmit = async () => {
    if (isOrdering) return;
    if (selectedItems.length === 0) {
      alert('กรุณาเลือกเมนูอย่างน้อย 1 รายการ');
      return;
    }
    setIsOrdering(true);
    const orderData = {
      tableNumber,
      items: selectedItems
    };
    try {
      const response = await fetch('http://localhost:5000/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      if (response.ok) {
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 2000);
        setSelectedItems([]);
      } else {
        alert('เกิดข้อผิดพลาดในการสั่งอาหาร');
      }
    } catch (error) {
      alert('เกิดข้อผิดพลาดในการเชื่อมต่อ Server');
    }
    setIsOrdering(false);
  };

  // ฟังก์ชันคำนวณราคาต่อชิ้น (รวม option)
  const getItemTotalPrice = (item) => {
    let extra = 0;
    if (item.options?.ขนาด === 'พิเศษ') extra += 10;
    if (item.options?.เพิ่มเติม && Array.isArray(item.options.เพิ่มเติม)) {
      if (item.options.เพิ่มเติม.includes('ห่อไข่')) extra += 10;
      if (item.options.เพิ่มเติม.includes('ไข่ดาว')) extra += 10;
      if (item.options.เพิ่มเติม.includes('ไข่เจียว')) extra += 10;
    }
    return (item.price + extra) * item.quantity;
  };

  // ฟังก์ชันคำนวณยอดรวมของออเดอร์ (ใช้ getItemTotalPrice)
  const getOrderTotal = (order) => order.items.reduce((sum, item) => sum + getItemTotalPrice(item), 0);

  // ยอดรวมทั้งหมดในตะกร้า
  const currentOrderTotal = selectedItems.reduce((sum, item) => sum + getItemTotalPrice(item), 0);
  // แยกหมวดหมู่เมนู
  const radnaItems = menuItems.filter(item => item.type === 'food' && item.name.includes('ราดหน้า'));
  // เมนูข้าว: type === 'food' และชื่อมี 'ข้าว'
  const riceItems = menuItems.filter(item => item.type === 'food' && item.name.includes('ข้าว'));
  const drinkItems = menuItems.filter(item => item.type === 'drink');
  const allOrdersTotal = tableOrders.reduce((sum, order) => sum + getOrderTotal(order), 0);

  // ฟังก์ชันเลือกชื่อเมนูตามภาษา
  const getMenuName = (item) => {
    if (language === 'en' && item.name_en) return item.name_en;
    if (language === 'cn' && item.name_cn) return item.name_cn;
    return item.name;
  };

  return (
    <div className="container customer-container">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 10}}>
        <h1 className="text-center" style={{margin:0}}>สั่งอาหาร (โต๊ะที่ {tableNumber})</h1>
        <div>
          <button onClick={() => setLanguage('th')} style={{marginRight:5, background: language==='th'?'#4CAF50':'#eee', color: language==='th'?'#fff':'#333', border:'1px solid #aaa', borderRadius:5, padding:'6px 12px', fontWeight:600}}>ไทย</button>
          <button onClick={() => setLanguage('en')} style={{marginRight:5, background: language==='en'?'#4CAF50':'#eee', color: language==='en'?'#fff':'#333', border:'1px solid #aaa', borderRadius:5, padding:'6px 12px', fontWeight:600}}>EN</button>
          <button onClick={() => setLanguage('cn')} style={{background: language==='cn'?'#4CAF50':'#eee', color: language==='cn'?'#fff':'#333', border:'1px solid #aaa', borderRadius:5, padding:'6px 12px', fontWeight:600}}>中文</button>
        </div>
      </div>

      {tableOrders.length > 0 && (
        <div className="current-orders-card">
          <h2>{language === 'en' ? 'Your Orders' : language === 'cn' ? '您的订单' : 'ออเดอร์ของคุณ'}</h2>
          {tableOrders.map(order => (
            <div key={order.id} className="summary-order-item">
              <p><b>ออเดอร์ #{order.id}</b></p>
              <ul>
                {order.items.map((item, index) => (
                  <li key={index}>
                    {getMenuName(item)}
                    {item.options?.เส้น ? ` (${language === 'en' ? 'Noodle' : language === 'cn' ? '面' : 'เส้น'}: ${item.options.เส้น})` : ''}
                    {item.options?.ขนาด ? ` (${language === 'en' ? 'Size' : language === 'cn' ? '份量' : 'ขนาด'}: ${item.options.ขนาด}${item.options.ขนาด === 'พิเศษ' ? '+10' : ''})` : ''}
                    {item.options?.เพิ่มเติม && item.options.เพิ่มเติม.length > 0 ? ` (${language === 'en' ? 'Add' : language === 'cn' ? '加料' : 'เพิ่มเติม'}: ${item.options.เพิ่มเติม.join(', ')}${item.options.เพิ่มเติม.includes('ห่อไข่') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่ดาว') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่เจียว') ? '+10' : ''})` : ''}
                    {' '}x {item.quantity} = <b>{getItemTotalPrice(item)} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</b>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <p className="total-price summary-total"><b>{language === 'en' ? 'Total:' : language === 'cn' ? '总计:' : 'ยอดรวมทั้งหมด:'} {allOrdersTotal} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</b></p>
        </div>
      )}

      <hr />

      <h2>{language === 'en' ? 'Radna Menu' : language === 'cn' ? '炒河粉菜单' : 'เมนูราดหน้า'}</h2>
      <div className="menu-grid radna-grid">
        {radnaItems.map(item => (
          <div key={item.id} className="menu-item-card" onClick={() => handleOpenModal(item)}>
            {/* รองรับรูปภาพทุกเมนู */}
            {item.image && <img src={item.image} alt={getMenuName(item)} className="menu-image" />}
            <div className="menu-info">
              <p className="menu-name">{getMenuName(item)}</p>
              <p className="menu-price">{item.price} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</p>
            </div>
          </div>
        ))}
      </div>

      <h2>{language === 'en' ? 'Rice Menu' : language === 'cn' ? '米饭菜单' : 'เมนูข้าว'}</h2>
      <div className="menu-grid rice-grid">
        {riceItems.map(item => (
          <div key={item.id} className="menu-item-card" onClick={() => handleOpenModal(item)}>
            {/* รองรับรูปภาพทุกเมนู */}
            {item.image && <img src={item.image} alt={getMenuName(item)} className="menu-image" />}
            <div className="menu-info">
              <p className="menu-name">{getMenuName(item)}</p>
              <p className="menu-price">{item.price} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</p>
            </div>
          </div>
        ))}
      </div>

      <h2>{language === 'en' ? 'Drinks' : language === 'cn' ? '饮料' : 'รายการเครื่องดื่ม'}</h2>
      <div className="menu-grid drink-grid">
        {drinkItems.map(item => (
          <div key={item.id} className="menu-item-card" onClick={() => handleAddItem({ ...item, options: {} })}>
            {/* รองรับรูปภาพทุกเมนู */}
            {item.image && <img src={item.image} alt={getMenuName(item)} className="menu-image" />}
            <div className="menu-info">
              <p className="menu-name">{getMenuName(item)}</p>
              <p className="menu-price">{item.price} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</p>
            </div>
          </div>
        ))}
      </div>

      <hr />

      <h3>{language === 'en' ? 'Selected Items:' : language === 'cn' ? '已选项目:' : 'รายการที่เลือก:'}</h3>
      <ul className="selected-items-list">
        {selectedItems.map((item, index) => {
          let extra = 0;
          if (item.options?.ขนาด === 'พิเศษ') extra += 10;
          if (item.options?.เพิ่มเติม && item.options.เพิ่มเติม.includes('ห่อไข่')) extra += 10;
          if (item.options?.เพิ่มเติม) {
            if (item.options.เพิ่มเติม.includes('ไข่ดาว')) extra += 10;
            if (item.options.เพิ่มเติม.includes('ไข่เจียว')) extra += 10;
          }
          const pricePerItem = item.price + extra;
          return (
            <li key={index}>
              <span>
                {getMenuName(item)}
                {item.options?.เส้น ? ` (${language === 'en' ? 'Noodle' : language === 'cn' ? '面' : 'เส้น'}: ${item.options.เส้น})` : ''}
                {item.options?.ขนาด ? ` (${language === 'en' ? 'Size' : language === 'cn' ? '份量' : 'ขนาด'}: ${item.options.ขนาด}${item.options.ขนาด === 'พิเศษ' ? '+10' : ''})` : ''}
                {item.options?.เพิ่มเติม && item.options.เพิ่มเติม.length > 0 ? ` (${language === 'en' ? 'Add' : language === 'cn' ? '加料' : 'เพิ่มเติม'}: ${item.options.เพิ่มเติม.join(', ')}${item.options.เพิ่มเติม.includes('ห่อไข่') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่ดาว') ? '+10' : ''}${item.options.เพิ่มเติม.includes('ไข่เจียว') ? '+10' : ''})` : ''}
                {' '}x {item.quantity} = <b>{pricePerItem * item.quantity} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</b>
              </span>
              <div className="item-controls">
                  <button onClick={() => handleMinus(index)} className="control-btn minus">-</button>
                  <span className="item-quantity">{item.quantity}</span>
                  <button onClick={() => handlePlus(index)} className="control-btn plus">+</button>
              </div>
            </li>
          );
        })}
      </ul>

      <p className="total-price"><b>{language === 'en' ? 'Total:' : language === 'cn' ? '总计:' : 'รวมทั้งหมด:'} {currentOrderTotal} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</b></p>

      <button onClick={handleOrderSubmit} className="order-button" disabled={isOrdering}>
        {isOrdering ? (language === 'en' ? 'Ordering...' : language === 'cn' ? '正在下单...' : 'กำลังส่งออเดอร์...') : (language === 'en' ? 'Confirm Order' : language === 'cn' ? '确认下单' : 'ยืนยันการสั่งซื้อ')}
      </button>

      {/* Confirmation Popup */}
      {showPopup && (
        <div className="popup-container">
          <div className="popup-content">
            <h2 className="popup-message">{language === 'en' ? 'Order Placed!' : language === 'cn' ? '下单成功！' : 'สั่งอาหารเรียบร้อย'}</h2>
          </div>
        </div>
      )}

      {/* Option Selection Modal */}
      {showModal && currentItem && (
          <div className="modal-container">
              <div className="modal-content">
                  <h2>{getMenuName(currentItem)}</h2>
                  <p className="menu-price">{currentItem.price} {language === 'en' ? 'Baht' : language === 'cn' ? '泰铢' : 'บาท'}</p>
                  {/* รองรับรูปภาพทุกเมนู */}
                  {currentItem.image && <img src={currentItem.image} alt={getMenuName(currentItem)} className="menu-image" style={{marginBottom: 10}} />}
                  {/* ตัวเลือกเส้น เฉพาะราดหน้า */}
                  {currentItem.options?.เส้น && (
                      <div className="option-group">
                          <p><b>เลือกเส้น:</b></p>
                          <select className="option-select" value={options.เส้น || ''} onChange={(e) => setOptions({...options, เส้น: e.target.value})}>
                              {currentItem.options.เส้น.map(option => (
                                  <option key={option} value={option}>{option}</option>
                              ))}
                          </select>
                      </div>
                  )}
                  {/* ตัวเลือกขนาด */}
                  {currentItem.options?.ขนาด && (
                      <div className="option-group">
                          <p><b>เลือกขนาด:</b></p>
                          <div className="radio-group">
                              {currentItem.options.ขนาด.map(option => (
                                  <label key={option} className="radio-label">
                                      <input 
                                          type="radio" 
                                          name="size" 
                                          value={option}
                                          checked={options.ขนาด === option}
                                          onChange={(e) => setOptions({...options, ขนาด: e.target.value})} 
                                      /> {option} {option === 'พิเศษ' ? '+10 บาท' : ''}
                                  </label>
                              ))}
                          </div>
                      </div>
                  )}
                  {/* ตัวเลือกเพิ่มเติม */}
                  {currentItem.options?.เพิ่มเติม && (
                      <div className="option-group">
                          <p><b>เลือกเพิ่มเติม:</b></p>
                          <div className="checkbox-group">
                            {currentItem.options.เพิ่มเติม.map(option => (
                                <label key={option} className="checkbox-label">
                                    <input 
                                        type="checkbox"
                                        checked={options.เพิ่มเติม.includes(option)}
                                        onChange={(e) => {
                                            const newAddons = e.target.checked
                                                ? [...options.เพิ่มเติม, option]
                                                : options.เพิ่มเติม.filter(o => o !== option);
                                            setOptions({...options, เพิ่มเติม: newAddons});
                                        }}
                                    /> {option} {(option === 'ห่อไข่' || option === 'ไข่ดาว' || option === 'ไข่เจียว') ? '+10 บาท' : ''}
                                </label>
                            ))}
                          </div>
                      </div>
                  )}
                  <div className="modal-buttons">
                      <button onClick={handleCloseModal} className="btn-cancel">ยกเลิก</button>
                      <button onClick={handleAddItemFromModal} className="btn-add">เพิ่มลงในตะกร้า</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
}

export default Customer;